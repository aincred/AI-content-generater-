
/** @type { import("drizzle-kit").Config } */
export default {
    schema: "./utils/schema.tsx",
    dialect: 'postgresql',
    dbCredentials: {
      url: 'postgresql://neondb_owner:BNc7aT9HvkfP@ep-tiny-unit-a18jy5d8.ap-southeast-1.aws.neon.tech/AI-Content-genratoR?sslmode=require'

    }
  };
  