import { Import, Search } from 'lucide-react'
import React from 'react'
function Header() {
  return (
    <div>
        <div className='p-5 shadow-sm border-b-2 bg-white flex justify-between items-center'>
            <div className='flex gap-2 items-center p-2 border rounded-md max-w-xl bg-white'>
                <Search/>
                <input type="text" placeholder='Search....' className=' outline-none' />

            </div>
            <div className='ml-2 left-4' >
                <h2 className=' bg-fuchsia-500 p-2 rounded-full text-xs text-white'>
                                      welcome to dashboard . . . . . . . . . . . . ..
                </h2>
            </div>
        </div>
    </div>
  )
}

export default Header